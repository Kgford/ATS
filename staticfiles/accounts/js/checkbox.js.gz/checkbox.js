function check()
{
  alert('checked');
  if (document.getElementById('_interval').checked) 
  {
      alert('checked');
  } else {
      alert('not checked');
  }
}